#include <stdio.h>
#include <stdlib.h>
#define MAX 20
struct list{
    int size;
    int data[MAX];
};
void init(struct list*);
int empty(struct list*);
int full(struct list*);
int size(struct list*);
void destroy(struct list*);
void retrieve(struct list*, int*, int);
void replace(struct list*, int, int);
int insert(struct list*, int, int);
int delete(struct list*, int*, int);
void multiple_insert(struct list*, int);
struct list merge(struct list*, struct list*);
struct list reverse(struct list*);
int middle(struct list*);
struct list group(struct list*);
int main(){
    struct list linkedlist1, linkedlist2, mergedlist;
    init(&linkedlist1);
    init(&linkedlist2);
    int n1, n2, x;
    printf("how many numbers will you insert in the list ");
    scanf("%d",&n1);
    multiple_insert(&linkedlist1,n1);
    printf("\nhow many numbers will you insert in the list ");
    scanf("%d",&n2);
    multiple_insert(&linkedlist2,n2);
    mergedlist= merge(&linkedlist1, &linkedlist2);
    printf("\nMerged List: ");
    for(x=0;x<mergedlist.size;x++) printf("%d ",mergedlist.data[x]);
    //printf("\n%d",mergedlist.size);
    printf("\nReversed List: ");
    struct list reversedlist;
    init(&reversedlist);
    reversedlist= reverse(&mergedlist);
    for(x=0;x<reversedlist.size;x++) printf("%d ",reversedlist.data[x]);
    //printf("\n%d",reversedlist.size);
    printf("\nMiddle Node: %d", middle(&mergedlist));
    int nth;
    struct list copy;
    copy=mergedlist;
    printf("\nwhich node do you want to remove ");
    scanf("%d",&nth);
    delete(&copy,&x,nth-1); //remove the nth node
    printf("\nUpdated Merged List: ");
    for(x=0;x<copy.size;x++) printf("%d ",copy.data[x]);
    copy= group(&mergedlist);
    printf("\nreturned list: ");
    for(x=0;x<copy.size;x++) printf("%d ",copy.data[x]);
    return 0;
}
void init(struct list* mylist){
    mylist->size=0;
}
int empty(struct list* mylist){
    return mylist->size==0;
}
int full(struct list* mylist){
    return mylist->size==MAX;
}
int size(struct list* mylist){
    return mylist->size;
}
void destroy(struct list* mylist){
    mylist->size=0;
}
void retrieve(struct list* mylist, int* x, int index){
    *x=mylist->data[index];
}
void replace(struct list* mylist, int x, int index){
    mylist->data[index]=x;
}
int insert(struct list* mylist, int x, int index){
    if(full(mylist)==1)
        return 0;
    for(int i= mylist->size-1;i>=index;i--)
        mylist->data[i+1]=mylist->data[i];
    mylist->data[index]=x;
    mylist->size++;
    return 1;
}
int delete(struct list* mylist, int*x, int index){
    if(empty(mylist)==1)
        return 0;
    *x= mylist->data[index];
    for(int i=index;i<mylist->size-1;i++)
        mylist->data[i]=mylist->data[i+1];
    mylist->size--;
    return 1;
}
void multiple_insert(struct list* mylist, int elements){
    int x,in[elements];
    printf("\nwrite the numbers inside your list ");
    for(x=0;x<elements;x++) 
    {
        scanf("%d",&in[x]);
        insert(mylist,in[x],x);
    }
}
struct list merge(struct list* list1, struct list* list2){
    int x, value, i= list1->size;
    struct list mergedlist;
    init(&mergedlist);
    for(x=0;x<list1->size;x++) 
    {
        retrieve(list1,&value,x);
        insert(&mergedlist,value,x);
    }
    for(x=0;x<list2->size;x++)
    {
        retrieve(list2,&value,x);
        insert(&mergedlist,value,i);
        i++;
    }
    return mergedlist;
}
struct list reverse(struct list* mylist){
    struct list reversedlist;
    init(&reversedlist);
    int i=0, value, x;
    for(x=mylist->size-1;x>=0;x--)
    {
        retrieve(mylist,&value,x);
        insert(&reversedlist,value,i);
        i++;
    }
    return reversedlist;
}
int middle(struct list*mylist){
    int x;
    if(mylist->size%2==0) //even
        x= mylist->size/2;
    else //odd
        x= (mylist->size-1)/2;
    return mylist->data[x];
}
struct list group(struct list*mylist){
    int x, value, iodd=0, ieven=0;
    struct list odd, even;
    init(&odd);
    init(&even);
    for(x=0;x<mylist->size;x++)
    {
        retrieve(mylist,&value,x);
        if(value%2!=0)
        {
            insert(&odd,value,iodd);
            iodd++;
        }
        else
        {
            insert(&even,value,ieven);
            ieven++;
        }
    }
    return merge(&odd,&even);
}
/*int cycle(struct list* mylist){
    mylist->data
}*/